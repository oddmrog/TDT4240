package oddmrog.copter.game.sprites;

import com.badlogic.gdx.graphics.Texture;
import com.badlogic.gdx.graphics.TextureArray;
import com.badlogic.gdx.graphics.g2d.TextureRegion;
import com.badlogic.gdx.math.Rectangle;
import com.badlogic.gdx.math.Vector3;
import com.badlogic.gdx.utils.Array;

import java.util.Random;

import oddmrog.copter.game.CopterGame;

/**
 * Created by oddmrog on 23.01.18.
 */

public class Copter {

    private Vector3 position;
    private Vector3 velocity;
    private Texture texture1, texture2, texture3, texture4;
    private boolean isFlipped;
    private Animation copterAnimation;
    private Array<TextureRegion> textureArray;
    private Random rand;
    private Rectangle bounds;
    private String name;

    public Copter(boolean randomPosition, String name){
        texture1 = new Texture("heli1.png");
        texture2 = new Texture("heli2.png");
        texture3 = new Texture("heli3.png");
        texture4 = new Texture("heli4.png");
        textureArray = new Array<TextureRegion>();
        textureArray.add(new TextureRegion(texture1));
        textureArray.add(new TextureRegion(texture2));
        textureArray.add(new TextureRegion(texture3));
        textureArray.add(new TextureRegion(texture4));
        rand = new Random();
        this.name = name;

        int maxX = CopterGame.WIDTH - 162;
        int maxY = CopterGame.HEIGHT - 65;
        int x = rand.nextInt(maxX);
        int y = rand.nextInt(maxY);
        bounds = new Rectangle(x, y, texture1.getWidth(), texture1.getHeight());

        position = new Vector3(x, y, 0);
        velocity = new Vector3(rand.nextInt(7500) - 2500 , rand.nextInt(2000)-1000, 0);
        isFlipped = false;
        copterAnimation = new Animation(textureArray, textureArray.size, 0.4f);
    }

    public void update(float dt){
        copterAnimation.update(dt);
        velocity.scl(dt);
        isWallCollision();
        position.add(velocity.x * dt, velocity.y * dt,0);
        velocity.scl(1/dt);
        bounds.setPosition(position.x, position.y);
    }

    public void isWallCollision(){
        if((bounds.x + texture1.getWidth()) > CopterGame.WIDTH || bounds.x < 0){
            setVelocity(-velocity.x, velocity.y, 0);
            bounce();
        }

        if(bounds.y > (CopterGame.HEIGHT - texture1.getHeight())|| bounds.y < 0){
            setVelocity(velocity.x, -velocity.y, 0);
        }

    }

    public void setVelocity(float x,float y,float z){
        velocity.set(x, y, z);
    }

    public void bounce(){
        System.out.println(name + " bounced");
        if(velocity.x < 0)
            isFlipped = true;
        else
            isFlipped = false;
    }

    public Vector3 getVelocity() {
        return velocity;
    }

    public Rectangle getBounds() {
        return bounds;
    }


    public TextureRegion getTextureRegion(){
        return copterAnimation.getFrame();
    }

    public Vector3 getPosition(){
        return position;
    }

    public boolean isFlipped(){
        return isFlipped;
    }

    public void turn(){
        velocity.rotate(Vector3.Z, 45);
        System.out.println("height of texture:" + texture1.getHeight());
        System.out.println("width of texture:" + texture1.getWidth());
    }


}
